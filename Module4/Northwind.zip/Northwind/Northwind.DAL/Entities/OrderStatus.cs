﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Northwind.DAL.Entities
{
    public enum OrderStatus
    {
        New,
        InWork,
        Completed
    }
}
