﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Northwind.DAL.Entities
{
    public class CustOrderHist
    {
        public string ProductName { get; set; }
        public int Total { get; set; }
    }
}
